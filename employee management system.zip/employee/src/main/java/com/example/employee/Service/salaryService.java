package com.example.employee.Service;

import org.springframework.stereotype.Component;

import com.example.employee.entity.Salary;

@Component
public interface salaryService {
	
	Salary getSalaryById(Long salaryId);
	
	Salary addSalary(Salary salary);

}
