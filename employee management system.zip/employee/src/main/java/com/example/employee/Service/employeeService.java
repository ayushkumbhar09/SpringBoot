package com.example.employee.Service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.example.employee.entity.Employee;

@Component
public interface employeeService {
	
	Employee addEmployee(Employee employee);
	
	List<Employee> getAllEmployee();
	
	Employee getEmployeeById(Long empId);
	
	Employee updateEmployeeById(Long empId,Employee employee);
	
	void deleteEmployeeById(Long empId);
	
	void deleteAllEmployee();
	
   boolean isEmployeeExist(Long empId);

}
