package com.example.employee.ServiceImplementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.employee.Repository.employeeRepository;
import com.example.employee.Service.employeeService;
import com.example.employee.entity.Employee;
@Service
public class employeeServiceImple implements employeeService{
    @Autowired
    private employeeRepository empRepo;
	@Override
	public Employee addEmployee(Employee employee) {
		
		return empRepo.save(employee);
	}

	@Override
	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		return empRepo.findAll();
	}

	@Override
	public Employee getEmployeeById(Long empId) {
		// TODO Auto-generated method stub
		return empRepo.findById(empId).get();
	}

	@Override
	public Employee updateEmployeeById(Long empId, Employee employee) {
		Employee e = empRepo.findById(empId).get();
		e.setDepartment(employee.getDepartment());
		e.setEmail(employee.getEmail());
		e.setEmpName(employee.getEmpName());
		e.setJoiningDate(employee.getJoiningDate());
		e.setManager(employee.getManager());
		return empRepo.save(e);
	}

	@Override
	public void deleteEmployeeById(Long empId) {
		// TODO Auto-generated method stub
		empRepo.findById(empId);
	}

	@Override
	public void deleteAllEmployee() {
		// TODO Auto-generated method stub
		empRepo.findAll();
	}

	@Override
	public boolean isEmployeeExist(Long empId) {
		// TODO Auto-generated method stub
		
		return empRepo.existsById(empId);
	}
	
	

}
