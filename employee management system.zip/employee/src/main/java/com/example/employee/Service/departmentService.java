package com.example.employee.Service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.example.employee.entity.Department;

@Component
public interface departmentService {
	
	Department getDepartmentById(Long deptId);
	
	List<Department> getAllDepartments();
	
	Department createDepartment(Department department);
	
	Department updateDepartmentById(Long deptId, Department department);
	
	void deleteDepartmentById(Long deptId);
	
	
	

}
