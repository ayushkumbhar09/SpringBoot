package com.example.employee.Controller;

import com.example.employee.Service.employeeService;
import com.example.employee.entity.Employee;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/Employee")
public class employeeController {
	@Autowired(required=true)
	private employeeService  empServ;

	
   @PostMapping("/add")
	public ResponseEntity<Employee>  addEmployee(@RequestBody Employee employee) {
		return new ResponseEntity<Employee>(empServ.addEmployee(employee),HttpStatus.CREATED);
	}
   @GetMapping("/getAll")
	public ResponseEntity<List<Employee>>  getAllEmployee() {
		return new ResponseEntity<List<Employee>>(empServ.getAllEmployee(),HttpStatus.OK);
	}
    @GetMapping("/get/{empId}")
	public ResponseEntity<Employee>  getEmployeeById(@PathVariable Long empId) {
		return new ResponseEntity<Employee>(empServ.getEmployeeById(empId),HttpStatus.OK);
	}
    @PutMapping("/update/empId")
	public ResponseEntity<Employee> updateEmployeeById(@PathVariable Long empId,@RequestBody Employee employee) {
		return new ResponseEntity<Employee>(empServ.updateEmployeeById(empId, employee),HttpStatus.OK);
	}
    @DeleteMapping("/delete/{empId}")
	public void deleteEmployeeById(@PathVariable Long empId) {
		empServ.deleteEmployeeById(empId);
	}
    @DeleteMapping("/deleteAll")
	public void deleteAllEmployee() {
		empServ.deleteAllEmployee();
	}

	public boolean isEmployeeExist(Long empId) {
		return empServ.isEmployeeExist(empId);
	}
	
	
	

}
