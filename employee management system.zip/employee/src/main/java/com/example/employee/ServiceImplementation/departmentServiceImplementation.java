package com.example.employee.ServiceImplementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.employee.Repository.departmentRepository;
import com.example.employee.Service.departmentService;
import com.example.employee.entity.Department;
@Service
public class departmentServiceImplementation implements departmentService{

	@Autowired
	private departmentRepository deptRepo;
	@Override
	public Department getDepartmentById(Long deptId) {
		// TODO Auto-generated method stub
		return deptRepo.findById(deptId).get();
		
	}

	@Override
	public List<Department> getAllDepartments() {
		// TODO Auto-generated method stub
		return deptRepo.findAll();
	}

	@Override
	public Department createDepartment(Department department) {
		// TODO Auto-generated method stub
		return deptRepo.save(department);
	}

	@Override
	public Department updateDepartmentById(Long deptId, Department department) {
		// TODO Auto-generated method stub
		Department d = deptRepo.findById(deptId).get();
		//d.setEmployee(department.getEmployee());
		d.setName(department.getName());
		d.setProject(department.getProject());
		return deptRepo.save(d);
	}

	@Override
	public void deleteDepartmentById(Long deptId) {
		// TODO Auto-generated method stub
		deptRepo.findById(deptId);
	}

}
