	package com.example.employee.ServiceImplementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.employee.Repository.projectRepository;
import com.example.employee.Service.projectService;
import com.example.employee.entity.Project;
@Service
public class projectServiceImplementation implements projectService{

	@Autowired
	private projectRepository projRepo; 
	@Override
	public List<Project> getAllProjects() {
		// TODO Auto-generated method stub
		return projRepo.findAll();
	}

	@Override
	public Project getProjectById(Long projectId) {
		// TODO Auto-generated method stub
		return projRepo.findById(projectId).get();
	}

	@Override
	public Project addProject(Project project) {
		// TODO Auto-generated method stub
		return projRepo.save(project);
	}

	@Override
	public void deleteProject(Long projectId) {
		// TODO Auto-generated method stub
		projRepo.findById(projectId);
	}

}
