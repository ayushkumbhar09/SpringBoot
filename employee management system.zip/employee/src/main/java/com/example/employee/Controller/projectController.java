package com.example.employee.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import com.example.employee.Service.projectService;
import com.example.employee.entity.Project;

@RestController
@RequestMapping("/Project")
public class projectController {
	@Autowired(required=true)
	private projectService projServ;

	@GetMapping("/getAll")
	public ResponseEntity<List<Project>>  getAllProjects() {
		return new ResponseEntity<List<Project>> (projServ.getAllProjects(),HttpStatus.OK);
	}

	@GetMapping("/get/{projectId}")
	public ResponseEntity<Project> getProjectById(@PathVariable Long projectId) {
		return new ResponseEntity<Project> (projServ.getProjectById(projectId),HttpStatus.OK);
	}

	 @PostMapping("/add")
	public ResponseEntity<Project> addProject(@RequestBody Project project) {
		return new ResponseEntity<Project> (projServ.addProject(project),HttpStatus.CREATED);
	}

	 @DeleteMapping("//delete/{projectId}")
	public void deleteProject(@PathVariable Long projectId) {
		projServ.deleteProject(projectId);
	}
	
	
	
	

}
