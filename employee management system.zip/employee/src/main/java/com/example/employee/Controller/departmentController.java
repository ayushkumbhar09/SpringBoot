package com.example.employee.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.employee.Service.departmentService;
import com.example.employee.entity.Department;

@RestController
@RequestMapping("/Department")
public class departmentController {
	@Autowired(required=true)
	private departmentService deptServ;

	@GetMapping("/get/{deptId}")
	public  ResponseEntity<Department> getDepartmentById(@PathVariable Long deptId) {
		return new ResponseEntity<Department> (deptServ.getDepartmentById(deptId),HttpStatus.OK);
	}

	@GetMapping("/getAll")
	public ResponseEntity<List<Department>>  getAllDepartments() {
		return new ResponseEntity<List<Department>> (deptServ.getAllDepartments(),HttpStatus.OK);
	}

	 @PostMapping("/add")
	public ResponseEntity< Department> createDepartment(@RequestBody Department department) {
		return new ResponseEntity<Department> (deptServ.createDepartment(department),HttpStatus.CREATED);
	}

	 @PutMapping("/update/empId")
	public ResponseEntity<Department>  updateDepartmentById(@PathVariable Long deptId,@RequestBody Department department) {
		return new ResponseEntity<Department> (deptServ.updateDepartmentById(deptId, department),HttpStatus.OK);
	}

	 @DeleteMapping("/delete/{deptId}")
	public void deleteDepartmentById(@PathVariable Long deptId) {
		deptServ.deleteDepartmentById(deptId);
	}
	
	
	

	
}
