 package com.example.employee.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
 

import com.example.employee.Service.salaryService;
import com.example.employee.entity.Salary;

@RestController
@RequestMapping("/Salary")
public class salaryController {
	@Autowired(required=true)
	private salaryService salserv;

	@GetMapping("/get/{salaryId}")
	public ResponseEntity<Salary> getSalaryById(@PathVariable Long salaryId) {
		return new ResponseEntity<Salary> (salserv.getSalaryById(salaryId),HttpStatus.OK);
	}

	@PostMapping("/add")
	public ResponseEntity<Salary> addSalary(@RequestBody Salary salary) {
		return new  ResponseEntity<Salary> (salserv.addSalary(salary),HttpStatus.OK);
	}
	
	

}
