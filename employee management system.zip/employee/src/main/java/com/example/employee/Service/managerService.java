package com.example.employee.Service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.example.employee.entity.Manager;

@Component
public interface managerService {
	
	List<Manager> getAllManagers();
	
	Manager getManagerById(Long managerId);
	
	Manager addManager(Manager manager);
	
	void deleteManagerById(Long managerId);

}
