package com.example.employee.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;

@Entity
@Table(name="Department")
public class Department {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long deptId;
	
	private String Name;
	@JsonIgnore
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="empId",referencedColumnName = "empId")
	private Employee employee;
	@JsonIgnore
	@OneToMany(mappedBy = "department",cascade = CascadeType.ALL)
	private List<Project> project;
	
	

	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public Department(String name, Employee employee, List<Project> project) {
		super();
		Name = name;
		this.employee = employee;
		this.project = project;
	}

	

	public Employee getEmployee() {
		return employee;
	}


	public void setEmployee(Employee employee) {
		this.employee = employee;
	}


	public List<Project> getProject() {
		return project;
	}


	public void setProject(List<Project> project) {
		this.project = project;
	}


	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}
	
	

}
