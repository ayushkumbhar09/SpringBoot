package com.example.employee.entity;


import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;
@Entity
@Table(name="Employee")
public class Employee {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long empId;
	@Column(nullable = false)
	private String empName;
	@Column(nullable = false)
	private String email;
	@JsonIgnore
	@OneToOne()
	private Department department;
	@JsonIgnore
	@OneToOne(mappedBy="employee",cascade=CascadeType.ALL)
	private Manager manager;
	@JsonIgnore
	@OneToOne(mappedBy = "employee",cascade = CascadeType.ALL)
	private Salary salary;
	

	@Column(nullable = false)
	private Date joiningDate;
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	public Employee(String empName, String email, Department department, Manager manager, Date joiningDate) {
		super();
		this.empName = empName;
		this.email = email;
		this.department = department;
		this.manager = manager;
		this.joiningDate = joiningDate;
	}



	public Salary getSalary() {
		return salary;
	}



	public void setSalary(Salary salary) {
		this.salary = salary;
	}



	public Date getJoiningDate() {
		return joiningDate;
	}



	public void setJoiningDate(Date joiningDate) {
		this.joiningDate = joiningDate;
	}



	public long getEmpId() {
		return empId;
	}
	public void setEmpId(long empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}



	public Department getDepartment() {
		return department;
	}



	public void setDepartment(Department department) {
		this.department = department;
	}



	public Manager getManager() {
		return manager;
	}



	public void setManager(Manager manager) {
		this.manager = manager;
	}
	
	
	

	


	
	

}
