package com.example.employee.Service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.example.employee.entity.Project;

@Component
public interface projectService {
	
	 List<Project> getAllProjects();
	 
	 Project getProjectById(Long projectId);
	 
	 Project addProject(Project project);
	 
	 void deleteProject(Long projectId);

}
