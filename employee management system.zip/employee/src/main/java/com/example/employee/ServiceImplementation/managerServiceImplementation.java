package com.example.employee.ServiceImplementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.employee.Repository.managerRepository;
import com.example.employee.Service.managerService;
import com.example.employee.entity.Manager;
@Service
public class managerServiceImplementation implements managerService {

	@Autowired
	private managerRepository manRepo;
	@Override
	public List<Manager> getAllManagers() {
		// TODO Auto-generated method stub
		return manRepo.findAll();
	}

	@Override
	public Manager getManagerById(Long managerId) {
		// TODO Auto-generated method stub
		return manRepo.findById(managerId).get();
	}

	@Override
	public Manager addManager(Manager manager) {
		// TODO Auto-generated method stub
		return manRepo.save(manager);
	}

	@Override
	public void deleteManagerById(Long managerId) {
		// TODO Auto-generated method stub
		manRepo.findById(managerId);
	}

}
