package com.example.employee.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.employee.entity.Department;

public interface departmentRepository extends JpaRepository<Department, Long> {

}
