package com.example.employee.entity;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.*;


@Entity
@Table(name="Project")
public class Project {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long projectId;
	@Column(nullable = false)
	private String name;
	@Column(nullable = false)
	private LocalDateTime startDate;
	@Column(nullable = false)
	private LocalDateTime endDate;
	@JsonIgnoreProperties
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="deptId",referencedColumnName = "deptId")
	private Department department;
	
	
	
	public Project() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Project(String name, LocalDateTime startDate, LocalDateTime endDate, Department department) {
		super();
		this.name = name;
		this.startDate = startDate;
		this.endDate = endDate;
		this.department = department;
	}


	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public LocalDateTime getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDateTime startDate) {
		this.startDate = startDate;
	}
	public LocalDateTime getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDateTime endDate) {
		this.endDate = endDate;
	}


	public Department getDepartment() {
		return department;
	}


	public void setDepartment(Department department) {
		this.department = department;
	}
	
	
	
	
	

}
