  package com.example.employee.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;


@Entity
@Table(name="Salary")
public class Salary {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long salaryId;
	public Long getSalaryId() {
		return salaryId;
	}



	public void setSalaryId(Long salaryId) {
		this.salaryId = salaryId;
	}



	@Column(nullable = false)
	private Long salary;
	@Column(nullable = false)
	private Long taxes;
	@JsonIgnore
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="empId",referencedColumnName = "empId")
	private Employee employee;	
	
	
	public Salary() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	public Salary(Long salary, Long taxes, Employee employee) {
		super();
		this.salary = salary;
		this.taxes = taxes;
		this.employee = employee;
	}



	public Long getSalary() {
		return salary;
	}

	public void setSalary(Long salary) {
		this.salary = salary;
	}

	public Long getTaxes() {
		return taxes;
	}

	public Employee getEmployee() {
		return employee;
	}



	public void setEmployee(Employee employee) {
		this.employee = employee;
	}



	public void setTaxes(Long taxes) {
		this.taxes = taxes;
	}
	
	

}
