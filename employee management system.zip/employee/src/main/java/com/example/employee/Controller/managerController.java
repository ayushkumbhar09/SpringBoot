package com.example.employee.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.employee.Service.managerService;
import com.example.employee.entity.Manager;

@RestController
@RequestMapping("/Manager")
public class managerController {
	@Autowired(required=true)
	private managerService manServ;

	 @GetMapping("/getAll")
	public ResponseEntity<List<Manager>> getAllManagers() {
		return new ResponseEntity<List<Manager>> (manServ.getAllManagers(),HttpStatus.OK);
	}

	 @GetMapping("/get/{managerId}")
	public ResponseEntity<Manager> getManagerById(@PathVariable Long managerId) {
		return new ResponseEntity<Manager> (manServ.getManagerById(managerId),HttpStatus.OK);
	}

	 @PostMapping("/add")
	public ResponseEntity<Manager> addManager(@RequestBody Manager manager) {
		return new ResponseEntity<Manager> (manServ.addManager(manager),HttpStatus.CREATED);
	}

	 @DeleteMapping("/delete/{managerId}")
	public void deleteManagerById(@PathVariable Long managerId) {
		manServ.deleteManagerById(managerId);
	}
	

}
