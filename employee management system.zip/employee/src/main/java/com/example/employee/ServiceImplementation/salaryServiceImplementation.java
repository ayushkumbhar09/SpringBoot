package com.example.employee.ServiceImplementation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.employee.Repository.salaryRepository;
import com.example.employee.Service.salaryService;
import com.example.employee.entity.Salary;
@Service
public class salaryServiceImplementation implements salaryService{

	@Autowired
	private salaryRepository salRepo;
	@Override
	public Salary getSalaryById(Long salaryId) {
		// TODO Auto-generated method stub
		return salRepo.findById(salaryId).get();
	}

	@Override
	public Salary addSalary(Salary salary) {
		// TODO Auto-generated method stub
		return salRepo.save(salary);
	}

}
